fastatocsvconverter is a python package that allows for manipulation of fasta files into csv formats. 
You can access it at https://pypi.org/project/fastatoscsvconverter/.

Ex run:
>> import fastatocsvconverter
>> fastatocsvconverter.converter.convert("pathtoyourfasta.fasta","new.csv")

